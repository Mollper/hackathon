"use client";

import { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Image as ImageIcon, Video, Loader2 } from 'lucide-react';

// Тип для сообщения
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Начальное сообщение от ИИ
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Привет! Я ИИ-помощник MyVille. Опишите проблему, скиньте фото, и я помогу правильно оформить заявку или подскажу нужный отдел.',
    }
  ]);

  // Автоскролл вниз при новом сообщении
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading, isOpen]);

  // Функция отправки сообщения
  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const newUserMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputText.trim(),
    };

    setMessages((prev) => [...prev, newUserMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      // Здесь мы стучимся к нашему бэкенду (создадим его на Шаге 2)
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: newUserMsg.content }),
      });

      if (!response.ok) throw new Error('Ошибка сети');

      const data = await response.json();
      
      const newAiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply || 'Произошла ошибка при обработке запроса.',
      };
      
      setMessages((prev) => [...prev, newAiMsg]);
    } catch (error) {
      console.error(error);
      setMessages((prev) => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: 'Ой, сервер сейчас недоступен. Попробуйте чуть позже! 🏙️'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Отправка по кнопке Enter
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="fixed bottom-24 md:bottom-8 right-4 md:right-8 z-50 flex flex-col items-end">
      
      {isOpen && (
        <div className="mb-4 w-[calc(100vw-2rem)] md:w-80 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden animate-in slide-in-from-bottom-5 fade-in duration-300 origin-bottom-right flex flex-col h-[450px]">
          
          {/* Шапка чата */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 flex justify-between items-center text-white shrink-0">
            <div className="flex items-center gap-2">
              <div className="bg-white/20 p-1.5 rounded-full">
                <Bot size={20} />
              </div>
              <div>
                <h3 className="font-bold text-sm">AI-Диспетчер</h3>
                <p className="text-[10px] text-blue-100 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                  На связи
                </p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded-full transition-colors">
              <X size={20} />
            </button>
          </div>

          {/* Область сообщений */}
          <div className="flex-1 p-4 overflow-y-auto bg-gray-50 flex flex-col gap-3">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`p-3 rounded-2xl text-sm shadow-sm max-w-[85%] ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white self-end rounded-tr-sm' 
                    : 'bg-white text-gray-800 self-start border border-gray-100 rounded-tl-sm'
                }`}
              >
                {msg.content}
              </div>
            ))}
            
            {/* Анимация печатания (Loading) */}
            {isLoading && (
              <div className="bg-white p-3 rounded-2xl rounded-tl-sm shadow-sm border border-gray-100 text-sm text-gray-800 self-start w-[60px] flex justify-center items-center h-[44px]">
                <div className="flex gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            )}
            {/* Якорь для скролла */}
            <div ref={messagesEndRef} />
          </div>

          {/* Панель ввода */}
          <div className="p-3 bg-white border-t border-gray-100 shrink-0">
            <div className="flex items-center gap-2 bg-gray-50 rounded-2xl border border-gray-200 p-1 focus-within:border-blue-500 transition-colors">
              <div className="flex gap-1 pl-2 text-gray-400 shrink-0">
                <button className="hover:text-blue-600 transition-colors"><ImageIcon size={18} /></button>
              </div>

              <input 
                type="text" 
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyPress}
                disabled={isLoading}
                placeholder="Напишите проблему..." 
                className="flex-1 bg-transparent text-sm p-2 outline-none disabled:opacity-50"
              />
              
              <button 
                onClick={handleSendMessage}
                disabled={!inputText.trim() || isLoading}
                className="bg-blue-600 text-white p-2 rounded-xl hover:bg-blue-700 transition-colors shadow-sm disabled:opacity-50 disabled:hover:bg-blue-600 shrink-0"
              >
                {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
              </button>
            </div>
          </div>
          
        </div>
      )}

      {/* Плавающая кнопка */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-xl hover:scale-110 transition-all duration-300 ${isOpen ? 'bg-gray-800 rotate-90 scale-90' : 'bg-gradient-to-r from-blue-600 to-indigo-600 animate-bounce'}`}
      >
        {isOpen ? <X size={24} /> : <Bot size={28} />}
      </button>
      
    </div>
  );
}