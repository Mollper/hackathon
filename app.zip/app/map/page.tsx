import { MapPin, Search, Filter } from 'lucide-react';

export default function MapPage() {
  return (
    <div className="relative h-[calc(100vh-64px)] md:h-screen w-full bg-[#e5e5f7] overflow-hidden animate-in fade-in duration-500" 
         style={{ backgroundImage: 'radial-gradient(#444cf7 0.5px, #e5e5f7 0.5px)', backgroundSize: '10px 10px' }}>
      
      {/* Поисковая строка поверх карты */}
      <div className="absolute top-4 left-4 right-4 md:left-8 md:right-8 z-10 flex gap-2">
        <div className="flex-1 flex items-center bg-white rounded-2xl shadow-lg px-4 py-3 border border-gray-100">
          <Search size={20} className="text-gray-400 mr-2" />
          <input type="text" placeholder="Поиск по району или улице..." className="flex-1 outline-none text-sm bg-transparent" />
        </div>
        <button className="bg-white p-3 rounded-2xl shadow-lg text-gray-600 hover:text-blue-600 border border-gray-100">
          <Filter size={20} />
        </button>
      </div>

      {/* Метки на карте (Симуляция) */}
      <div className="absolute top-[30%] left-[40%] flex flex-col items-center group cursor-pointer">
        <div className="bg-red-500 text-white p-2 rounded-full shadow-lg group-hover:scale-110 transition-transform">
          <MapPin size={24} />
        </div>
        <div className="opacity-0 group-hover:opacity-100 bg-white px-3 py-1 rounded-lg text-xs font-bold shadow-md mt-1 transition-opacity absolute top-10 whitespace-nowrap z-20">
          Открытый люк
        </div>
      </div>

      <div className="absolute top-[60%] left-[20%] flex flex-col items-center group cursor-pointer">
        <div className="bg-yellow-500 text-white p-2 rounded-full shadow-lg group-hover:scale-110 transition-transform">
          <MapPin size={24} />
        </div>
      </div>

      <div className="absolute top-[45%] left-[70%] flex flex-col items-center group cursor-pointer">
        <div className="bg-green-500 text-white p-2 rounded-full shadow-lg group-hover:scale-110 transition-transform">
          <MapPin size={24} />
        </div>
      </div>

      {/* Всплывающая карточка снизу */}
      <div className="absolute bottom-6 left-4 right-4 md:left-8 md:right-8 z-10">
        <div className="bg-white rounded-3xl p-4 shadow-xl border border-gray-100 flex items-center gap-4">
          <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center text-red-500">
            <MapPin size={28} />
          </div>
          <div className="flex-1">
            <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider mb-1 block">Дороги</span>
            <h3 className="font-bold text-sm text-gray-900 leading-tight">Открытый люк на тротуаре</h3>
            <p className="text-xs text-gray-500 mt-1">пр. Абылай Хана, 120</p>
          </div>
        </div>
      </div>
    </div>
  );
}