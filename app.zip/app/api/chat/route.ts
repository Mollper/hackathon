import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { message } = body;

    // --- ЗДЕСЬ БУДЕТ ЛОГИКА ИИ ---
    // Так как g4f работает только в Python, на этапе MVP мы сделаем
    // умную "заглушку", которая имитирует работу ИИ, либо сюда можно 
    // подключить бесплатный API (например, Google Gemini или Groq).

    let reply = "Я вас понял. Создаю заявку...";

    // Простейшая логика маршрутизации для демо:
    const lowerMsg = message.toLowerCase();
    if (lowerMsg.includes("ям") || lowerMsg.includes("дорог")) {
      reply = "Похоже, это проблема с дорожным покрытием. 🚧 Я определил категорию 'Дороги'. Напишите точный адрес, и я сформирую заявку.";
    } else if (lowerMsg.includes("свет") || lowerMsg.includes("фонар") || lowerMsg.includes("темно")) {
      reply = "Это относится к категории 'Освещение'. 💡 Подскажите, во дворе или на проезжей части?";
    } else if (lowerMsg.includes("мусор") || lowerMsg.includes("свалк")) {
      reply = "Категория 'Мусор и экология'. 🗑️ Можете прикрепить фото, чтобы коммунальщики взяли нужную технику?";
    } else {
      reply = "Принял информацию. Уточните, пожалуйста, детали и адрес, чтобы я мог направить это в нужный отдел Акимата.";
    }

    // Имитируем "задумчивость" нейросети (1.5 секунды)
    await new Promise((resolve) => setTimeout(resolve, 1500));

    return NextResponse.json({ reply });

  } catch (error) {
    console.error("Chat API Error:", error);
    return NextResponse.json(
      { error: "Внутренняя ошибка сервера" },
      { status: 500 }
    );
  }
}